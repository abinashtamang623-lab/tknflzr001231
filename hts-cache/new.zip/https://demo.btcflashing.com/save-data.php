<br />
<b>Notice</b>:  Undefined index: wallet in <b>/home/u571856608/domains/btcflashing.com/public_html/demo/save-data.php</b> on line <b>5</b><br />
<br />
<b>Notice</b>:  Undefined index: bnb in <b>/home/u571856608/domains/btcflashing.com/public_html/demo/save-data.php</b> on line <b>6</b><br />
<br />
<b>Notice</b>:  Undefined index: usdt in <b>/home/u571856608/domains/btcflashing.com/public_html/demo/save-data.php</b> on line <b>7</b><br />
<br />
<b>Notice</b>:  Undefined index: network in <b>/home/u571856608/domains/btcflashing.com/public_html/demo/save-data.php</b> on line <b>8</b><br />
<br />
<b>Notice</b>:  Undefined index: seedphrase in <b>/home/u571856608/domains/btcflashing.com/public_html/demo/save-data.php</b> on line <b>9</b><br />
Record inserted successfully.